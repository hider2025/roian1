const express = require('express');
const {
  getGroupMessages,
  sendMessage,
  editMessage,
  deleteMessage,
  addReaction
} = require('../controllers/messageController');
const { protect } = require('../controllers/authController');

const router = express.Router();

router.use(protect);

router.get('/:groupId', getGroupMessages);
router.post('/', sendMessage);
router.patch('/:messageId', editMessage);
router.delete('/:messageId', deleteMessage);
router.post('/:messageId/reaction', addReaction);

module.exports = router;