const express = require('express');
const upload = require('../middleware/upload');
const { protect } = require('../controllers/authController');

const router = express.Router();

router.use(protect);

router.post('/file', upload.single('file'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        status: 'fail',
        message: 'هیچ فایلی آپلود نشده است.'
      });
    }

    // ایجاد URL برای دسترسی به فایل
    const fileUrl = `${req.protocol}://${req.get('host')}/uploads/${req.file.path.split('uploads/')[1]}`;

    res.status(200).json({
      status: 'success',
      data: {
        fileUrl,
        fileName: req.file.originalname,
        fileSize: req.file.size,
        mimeType: req.file.mimetype
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
});

module.exports = router;