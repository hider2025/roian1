const express = require('express');
const { createGroup, getUserGroups, joinGroup } = require('../controllers/groupController');
const { protect } = require('../controllers/authController');

const router = express.Router();

router.use(protect);

router.post('/', createGroup);
router.get('/', getUserGroups);
router.post('/join', joinGroup);

module.exports = router;