const Message = require('../models/Message');
const Group = require('../models/Group');
const User = require('../models/User');

exports.getGroupMessages = async (req, res) => {
  try {
    const { groupId } = req.params;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 50;
    const skip = (page - 1) * limit;

    // بررسی عضویت کاربر در گروه
    const group = await Group.findById(groupId);
    if (!group.members.includes(req.user._id)) {
      return res.status(403).json({
        status: 'fail',
        message: 'شما به این گروه دسترسی ندارید.'
      });
    }

    const messages = await Message.find({ group: groupId })
      .populate('sender', 'name username profilePicture')
      .populate('replyTo')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);

    res.status(200).json({
      status: 'success',
      results: messages.length,
      data: {
        messages: messages.reverse()
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};

exports.sendMessage = async (req, res) => {
  try {
    const { groupId, text, type, fileUrl, fileName, fileSize, replyTo } = req.body;
    const sender = req.user._id;

    // بررسی عضویت کاربر در گروه
    const group = await Group.findById(groupId);
    if (!group.members.includes(sender)) {
      return res.status(403).json({
        status: 'fail',
        message: 'شما به این گروه دسترسی ندارید.'
      });
    }

    const newMessage = await Message.create({
      sender,
      group: groupId,
      text,
      type: type || 'text',
      fileUrl: fileUrl || '',
      fileName: fileName || '',
      fileSize: fileSize || '',
      replyTo: replyTo || null
    });

    await newMessage.populate('sender', 'name username profilePicture');
    await newMessage.populate('replyTo');

    // به‌روزرسانی زمان آخرین فعالیت گروه
    group.updatedAt = new Date();
    await group.save();

    res.status(201).json({
      status: 'success',
      data: {
        message: newMessage
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};

exports.editMessage = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { text } = req.body;

    const message = await Message.findById(messageId);
    
    if (!message) {
      return res.status(404).json({
        status: 'fail',
        message: 'پیام مورد نظر یافت نشد.'
      });
    }

    // بررسی مالکیت پیام
    if (message.sender.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        status: 'fail',
        message: 'شما اجازه ویرایش این پیام را ندارید.'
      });
    }

    message.text = text;
    message.edited = true;
    await message.save();

    await message.populate('sender', 'name username profilePicture');
    await message.populate('replyTo');

    res.status(200).json({
      status: 'success',
      data: {
        message
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};

exports.deleteMessage = async (req, res) => {
  try {
    const { messageId } = req.params;

    const message = await Message.findById(messageId);
    
    if (!message) {
      return res.status(404).json({
        status: 'fail',
        message: 'پیام مورد نظر یافت نشد.'
      });
    }

    // بررسی مالکیت پیام یا ادمین بودن
    const group = await Group.findById(message.group);
    const isAdmin = group.admins.includes(req.user._id);
    
    if (message.sender.toString() !== req.user._id.toString() && !isAdmin) {
      return res.status(403).json({
        status: 'fail',
        message: 'شما اجازه حذف این پیام را ندارید.'
      });
    }

    await Message.findByIdAndDelete(messageId);

    res.status(204).json({
      status: 'success',
      data: null
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};

exports.addReaction = async (req, res) => {
  try {
    const { messageId } = req.params;
    const { emoji } = req.body;
    const userId = req.user._id;

    const message = await Message.findById(messageId);
    
    if (!message) {
      return res.status(404).json({
        status: 'fail',
        message: 'پیام مورد نظر یافت نشد.'
      });
    }

    // بررسی وجود راکشن کاربر
    const existingReactionIndex = message.reactions.findIndex(
      reaction => reaction.user.toString() === userId.toString() && reaction.emoji === emoji
    );

    if (existingReactionIndex > -1) {
      // حذف راکشن اگر وجود دارد
      message.reactions.splice(existingReactionIndex, 1);
    } else {
      // افزودن راکشن جدید
      message.reactions.push({ user: userId, emoji });
    }

    await message.save();
    await message.populate('reactions.user', 'name username profilePicture');

    res.status(200).json({
      status: 'success',
      data: {
        message
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};