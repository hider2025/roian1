const User = require('../models/User');
const jwt = require('jsonwebtoken');
const { promisify } = require('util');

const signToken = id => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN
  });
};

exports.register = async (req, res) => {
  try {
    const { name, username, password, profilePicture } = req.body;

    // بررسی وجود کاربر
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({
        status: 'fail',
        message: 'این نام کاربری قبلاً استفاده شده است.'
      });
    }

    // ایجاد کاربر جدید
    const newUser = await User.create({
      name,
      username,
      password,
      profilePicture: profilePicture || ''
    });

    // تولید توکن
    const token = signToken(newUser._id);

    // حذف پسورد از خروجی
    newUser.password = undefined;

    res.status(201).json({
      status: 'success',
      token,
      data: {
        user: newUser
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body;

    // بررسی وجود کاربر و پسورد
    if (!username || !password) {
      return res.status(400).json({
        status: 'fail',
        message: 'لطفاً نام کاربری و رمز عبور را وارد کنید.'
      });
    }

    // پیدا کردن کاربر و بررسی پسورد
    const user = await User.findOne({ username }).select('+password');
    
    if (!user || !(await user.correctPassword(password, user.password))) {
      return res.status(401).json({
        status: 'fail',
        message: 'نام کاربری یا رمز عبور اشتباه است.'
      });
    }

    // به‌روزرسانی وضعیت آنلاین
    user.isOnline = true;
    await user.save({ validateBeforeSave: false });

    // تولید توکن
    const token = signToken(user._id);

    // حذف پسورد از خروجی
    user.password = undefined;

    res.status(200).json({
      status: 'success',
      token,
      data: {
        user
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};

exports.protect = async (req, res, next) => {
  try {
    // گرفتن توکن و بررسی وجود آن
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({
        status: 'fail',
        message: 'لطفاً وارد حساب کاربری خود شوید.'
      });
    }

    // verify توکن
    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);

    // بررسی وجود کاربر
    const currentUser = await User.findById(decoded.id);
    if (!currentUser) {
      return res.status(401).json({
        status: 'fail',
        message: 'کاربر مربوط به این توکن وجود ندارد.'
      });
    }

    // ذخیره کاربر در req
    req.user = currentUser;
    next();
  } catch (err) {
    res.status(401).json({
      status: 'fail',
      message: 'لطفاً مجدداً وارد حساب کاربری خود شوید.'
    });
  }
};