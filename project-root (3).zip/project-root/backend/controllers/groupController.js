const Group = require('../models/Group');
const User = require('../models/User');
const crypto = require('crypto');

exports.createGroup = async (req, res) => {
  try {
    const { name, description, avatar, isPublic } = req.body;
    const creator = req.user._id;

    // ایجاد لینک دعوت یکتا
    const inviteLink = crypto.randomBytes(8).toString('hex');

    const newGroup = await Group.create({
      name,
      description: description || '',
      avatar: avatar || '',
      creator,
      members: [creator],
      admins: [creator],
      inviteLink,
      isPublic: isPublic || false
    });

    await newGroup.populate('creator', 'name username profilePicture');
    await newGroup.populate('members', 'name username profilePicture');

    res.status(201).json({
      status: 'success',
      data: {
        group: newGroup
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};

exports.getUserGroups = async (req, res) => {
  try {
    const userId = req.user._id;

    const groups = await Group.find({ 
      members: userId 
    })
    .populate('creator', 'name username profilePicture')
    .populate('members', 'name username profilePicture')
    .sort({ updatedAt: -1 });

    res.status(200).json({
      status: 'success',
      results: groups.length,
      data: {
        groups
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};

exports.joinGroup = async (req, res) => {
  try {
    const { inviteLink } = req.body;
    const userId = req.user._id;

    const group = await Group.findOne({ inviteLink });
    
    if (!group) {
      return res.status(404).json({
        status: 'fail',
        message: 'لینک دعوت معتبر نیست.'
      });
    }

    // بررسی عضویت کاربر در گروه
    if (group.members.includes(userId)) {
      return res.status(400).json({
        status: 'fail',
        message: 'شما قبلاً در این گروه عضو هستید.'
      });
    }

    // افزودن کاربر به گروه
    group.members.push(userId);
    await group.save();

    await group.populate('creator', 'name username profilePicture');
    await group.populate('members', 'name username profilePicture');

    res.status(200).json({
      status: 'success',
      data: {
        group
      }
    });
  } catch (err) {
    res.status(400).json({
      status: 'fail',
      message: err.message
    });
  }
};