const Message = require('../models/Message');
const Group = require('../models/Group');
const User = require('../models/User');

module.exports = (io) => {
  io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    // پیوستن به اتاق گروه
    socket.on('join-group', (groupId) => {
      socket.join(groupId);
      console.log(`User ${socket.id} joined group ${groupId}`);
    });

    // ترک کردن اتاق گروه
    socket.on('leave-group', (groupId) => {
      socket.leave(groupId);
      console.log(`User ${socket.id} left group ${groupId}`);
    });

    // ارسال پیام جدید
    socket.on('send-message', async (data) => {
      try {
        const { groupId, text, type, fileUrl, fileName, fileSize, replyTo } = data;
        
        // ذخیره پیام در دیتابیس
        const message = await Message.create({
          sender: socket.userId,
          group: groupId,
          text,
          type: type || 'text',
          fileUrl: fileUrl || '',
          fileName: fileName || '',
          fileSize: fileSize || '',
          replyTo: replyTo || null
        });

        await message.populate('sender', 'name username profilePicture');
        await message.populate('replyTo');

        // ارسال پیام به همه کاربران در گروه
        io.to(groupId).emit('new-message', message);

        // به‌روزرسانی زمان آخرین فعالیت گروه
        await Group.findByIdAndUpdate(groupId, { updatedAt: new Date() });
      } catch (err) {
        console.error('Error sending message:', err);
        socket.emit('error', { message: 'خطا در ارسال پیام' });
      }
    });

    // ویرایش پیام
    socket.on('edit-message', async (data) => {
      try {
        const { messageId, text } = data;

        const message = await Message.findById(messageId);
        
        if (!message) {
          socket.emit('error', { message: 'پیام مورد نظر یافت نشد' });
          return;
        }

        // بررسی مالکیت پیام
        if (message.sender.toString() !== socket.userId) {
          socket.emit('error', { message: 'شما اجازه ویرایش این پیام را ندارید' });
          return;
        }

        message.text = text;
        message.edited = true;
        await message.save();

        await message.populate('sender', 'name username profilePicture');
        await message.populate('replyTo');

        // ارسال پیام ویرایش شده به همه کاربران در گروه
        io.to(message.group.toString()).emit('message-edited', message);
      } catch (err) {
        console.error('Error editing message:', err);
        socket.emit('error', { message: 'خطا در ویرایش پیام' });
      }
    });

    // حذف پیام
    socket.on('delete-message', async (data) => {
      try {
        const { messageId } = data;

        const message = await Message.findById(messageId);
        
        if (!message) {
          socket.emit('error', { message: 'پیام مورد نظر یافت نشد' });
          return;
        }

        // بررسی مالکیت پیام یا ادمین بودن
        const group = await Group.findById(message.group);
        const isAdmin = group.admins.includes(socket.userId);
        
        if (message.sender.toString() !== socket.userId && !isAdmin) {
          socket.emit('error', { message: 'شما اجازه حذف این پیام را ندارید' });
          return;
        }

        await Message.findByIdAndDelete(messageId);

        // اطلاع به همه کاربران در گروه
        io.to(message.group.toString()).emit('message-deleted', messageId);
      } catch (err) {
        console.error('Error deleting message:', err);
        socket.emit('error', { message: 'خطا در حذف پیام' });
      }
    });

    // افزودن راکشن
    socket.on('add-reaction', async (data) => {
      try {
        const { messageId, emoji } = data;

        const message = await Message.findById(messageId);
        
        if (!message) {
          socket.emit('error', { message: 'پیام مورد نظر یافت نشد' });
          return;
        }

        // بررسی وجود راکشن کاربر
        const existingReactionIndex = message.reactions.findIndex(
          reaction => reaction.user.toString() === socket.userId && reaction.emoji === emoji
        );

        if (existingReactionIndex > -1) {
          // حذف راکشن اگر وجود دارد
          message.reactions.splice(existingReactionIndex, 1);
        } else {
          // افزودن راکشن جدید
          message.reactions.push({ user: socket.userId, emoji });
        }

        await message.save();
        await message.populate('reactions.user', 'name username profilePicture');

        // ارسال راکشن به روز شده به همه کاربران در گروه
        io.to(message.group.toString()).emit('reaction-added', message);
      } catch (err) {
        console.error('Error adding reaction:', err);
        socket.emit('error', { message: 'خطا در افزودن راکشن' });
      }
    });

    // وضعیت تایپ کردن
    socket.on('typing-start', (data) => {
      const { groupId, userId } = data;
      socket.to(groupId).emit('user-typing', { userId, typing: true });
    });

    socket.on('typing-stop', (data) => {
      const { groupId, userId } = data;
      socket.to(groupId).emit('user-typing', { userId, typing: false });
    });

    socket.on('disconnect', () => {
      console.log('User disconnected:', socket.id);
    });
  });
};