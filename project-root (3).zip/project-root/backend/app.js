const express = require('express');
const cors = require('cors');
const path = require('path');
const authRoutes = require('./routes/auth');
const groupRoutes = require('./routes/groups');
const messageRoutes = require('./routes/messages');
const uploadRoutes = require('./routes/upload');

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// مسیر برای فایل‌های آپلود شده
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/groups', groupRoutes);
app.use('/api/messages', messageRoutes);
app.use('/api/upload', uploadRoutes);

// Route برای بررسی سلامت سرور
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'سرور فعال است'
  });
});

// مدیریت خطاهای 404
app.all('*', (req, res) => {
  res.status(404).json({
    status: 'fail',
    message: `مسیر ${req.originalUrl} یافت نشد`
  });
});

// مدیریت خطاهای全局
app.use((err, req, res, next) => {
  console.error(err.stack);
  
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        status: 'fail',
        message: 'حجم فایل بسیار بزرگ است'
      });
    }
  }
  
  res.status(500).json({
    status: 'error',
    message: 'خطای سرور داخلی'
  });
});

module.exports = app;