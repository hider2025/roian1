const jwt = require('jsonwebtoken');
const User = require('../models/User');

const socketAuth = async (socket, next) => {
  try {
    const token = socket.handshake.auth.token;
    
    if (!token) {
      return next(new Error('لطفاً وارد حساب کاربری خود شوید.'));
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    
    if (!user) {
      return next(new Error('کاربر مربوط به این توکن وجود ندارد.'));
    }

    // به‌روزرسانی وضعیت آنلاین
    user.isOnline = true;
    await user.save({ validateBeforeSave: false });

    socket.userId = user._id;
    next();
  } catch (err) {
    next(new Error('لطفاً مجدداً وارد حساب کاربری خود شوید.'));
  }
};

module.exports = socketAuth;